export let _apiFetchConstants = {
  urlApi : 'http://192.168.0.24:3001/',
  result : 0,
  video: "",
  recharge: false,
}
