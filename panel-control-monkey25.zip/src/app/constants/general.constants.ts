export let _generalConstants = {

}
