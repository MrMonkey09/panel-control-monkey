export let _videoConstants = {
  recharge: false,
  video: '',
};
