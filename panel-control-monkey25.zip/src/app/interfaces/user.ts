export interface User_ {
  ID?: number;
  Name: string;
  Password: string;
  Email: string;
  DepartmentID: number;
  Rut: string;
}