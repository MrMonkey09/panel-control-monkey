export interface Screen_ {
  ID: number;
  IP?: string;
  Brand: string;
  CurrentGroupID?: number;
  LocationID: number;
  DepartmentID: number;
}
