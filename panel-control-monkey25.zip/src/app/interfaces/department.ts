export interface Department_ {
  ID: number;
  Name: string;
}
