export interface Location_ {
    ID: number,
    Name: string,
}