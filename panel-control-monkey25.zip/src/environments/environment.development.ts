export const environment = {
  PORT: '9595',
  HOST: '192.168.0.24',
};
