# panel-control-monkey
 Panel de control para la distribucion de multimedia por medio de red local a grupos de monitores
